-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2023 at 08:46 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bantour`
--

-- --------------------------------------------------------

--
-- Table structure for table `chitietdattour`
--

CREATE TABLE `chitietdattour` (
  `khachhang_MaKH` bigint(20) NOT NULL,
  `tour_MaTour` bigint(20) NOT NULL,
  `NgayBD` datetime NOT NULL,
  `NgayKT` datetime NOT NULL,
  `GiaTour` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diadiem`
--

CREATE TABLE `diadiem` (
  `MaDD` bigint(20) NOT NULL,
  `TenDD` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `DiaChi` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `MoTa` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `diadiem`
--

INSERT INTO `diadiem` (`MaDD`, `TenDD`, `DiaChi`, `MoTa`) VALUES
(1, 'Stay And Chill', NULL, 'home stay'),
(2, 'Ban Mê', NULL, NULL),
(3, 'SaiGon1988', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dichvu`
--

CREATE TABLE `dichvu` (
  `MaDV` bigint(20) NOT NULL,
  `TenDV` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `MoTa` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `GiaTien` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dichvu`
--

INSERT INTO `dichvu` (`MaDV`, `TenDV`, `MoTa`, `GiaTien`) VALUES
(1, 'Vận chuyển', 'Xe đưa đón', '200000.00'),
(2, 'Vận chuyển', 'Xe đưa đón', '200000.00'),
(3, 'hướng dẫn', 'giới thiệu', '300000.00'),
(4, 'nghỉ ngơi', 'nhà nghỉ', '700000.00'),
(5, 'ăn uống', 'ăn', '400000.00'),
(6, 'chụp ảnh', 'chụp ảnh', '900000.00'),
(7, 'phương tiện', 'máy bay, xe trung chuyển', '300000.00'),
(8, 'bảo hiểm', 'y tế', '100000.00');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `huongdanvien`
--

CREATE TABLE `huongdanvien` (
  `TenHDV` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CCCD` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ChuyenMon` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `HuongDanViencol` varchar(45) NOT NULL,
  `NhanVien_MaNV` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `huongdanvien`
--

INSERT INTO `huongdanvien` (`TenHDV`, `CCCD`, `Phone`, `ChuyenMon`, `HuongDanViencol`, `NhanVien_MaNV`) VALUES
('Thịnh', '079267584253', '0915974982', 'pr', '1', 1),
('Linh', '079472849509', '0915974943', 'care', '1', 4);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `MaKH` bigint(20) NOT NULL,
  `TenKH` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CMND` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `DiaChi` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `khachhang_users` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`MaKH`, `TenKH`, `CMND`, `Phone`, `DiaChi`, `khachhang_users`) VALUES
(2, 'Trần Minh', '079200001007', '0913535676', '14/7  Hoàng Minh Giám, quận Bình Thạnh', 2),
(3, 'Minh Trần Nhật', '079300001004', '0912287397', '50 Thành Thái, phường 12, quận 10', 3),
(4, 'Phạm Minh', '097100001008', '0978134235', '79/82 Âu Dương Lân, quận 8', 4),
(5, 'Gia Hân', '079400001009', '0987123456', '34/1/45 Thành Thái, quận 10', 5);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2019_05_03_000001_create_customer_columns', 2),
(7, '2019_05_03_000002_create_subscriptions_table', 2),
(8, '2019_05_03_000003_create_subscription_items_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

CREATE TABLE `nhanvien` (
  `MaNV` bigint(20) NOT NULL,
  `HoTen` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `NgaySinh` varchar(45) NOT NULL,
  `DiaChi` varchar(45) DEFAULT NULL,
  `Phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `nhanvien`
--

INSERT INTO `nhanvien` (`MaNV`, `HoTen`, `Email`, `NgaySinh`, `DiaChi`, `Phone`) VALUES
(1, 'Thịnh', 'thinh@gmail.com', '18/03/1997', NULL, '0915974982'),
(2, 'Quý', 'quyy@gmail.com', '11/11/2000', NULL, '0915973582'),
(3, 'Hoàng', 'hoang@gmail.com', '18/08/1999', NULL, '0915543982'),
(4, 'Linh', 'linh@gmail.com', '10/01/1989', NULL, '0915974943'),
(5, 'Phan', 'phan@gmail.com', '28/02/1990', NULL, '0915998662'),
(6, 'Quốc', 'quoc@gmail.com', '12/07/1999', NULL, '0915970982');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('2051052081minh@ou.edu.vn', '$2y$10$wZryyeZZcBOm2PRllzCabOpmzsmOtRxBEU3bajhReMui21YVT0Vqu', '2023-03-19 00:35:46');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `stripe_id` varchar(255) NOT NULL,
  `stripe_status` varchar(255) NOT NULL,
  `stripe_price` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_items`
--

CREATE TABLE `subscription_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subscription_id` bigint(20) UNSIGNED NOT NULL,
  `stripe_id` varchar(255) NOT NULL,
  `stripe_product` varchar(255) NOT NULL,
  `stripe_price` varchar(255) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taikhoanadmin`
--

CREATE TABLE `taikhoanadmin` (
  `ID` bigint(20) NOT NULL,
  `name` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `NhanVien_MaNV` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tour`
--

CREATE TABLE `tour` (
  `MaTour` bigint(20) NOT NULL,
  `TenTour` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ThoiGian` date NOT NULL,
  `MoTa` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `huongdanvien_MaHDV` int(11) NOT NULL,
  `huongdanvien_NhanVien_MaNV` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `tour`
--

INSERT INTO `tour` (`MaTour`, `TenTour`, `ThoiGian`, `MoTa`, `huongdanvien_MaHDV`, `huongdanvien_NhanVien_MaNV`) VALUES
(1, 'Canada', '2023-03-15', 'Hồ Louise là một bản giao hưởng tuyệt diệu của thiên nhiên Canada.', 1, 1),
(2, 'Đà Lạt', '2023-03-23', 'Đà Lạt thơ mộng với những sườn núi ẩn hiện khuất tầm mắt sau làn sương mù.', 1, 1),
(3, 'Hà Giang', '2023-03-31', 'Sông Nho Quế mỹ lệ với làn nước trong vắt màu xanh ngọc bích, dòng chảy nhẹ nhàng uyển chuyển.', 1, 1),
(4, 'Nhật Bản', '2023-03-25', 'Núi Phú Sĩ hùng vĩ là niềm tự hào của người dân nơi đây.', 1, 4),
(5, 'Carolina', '2023-03-27', 'Một vẻ đẹp da diết siết chặt lấy những con người với niềm nhớ thương hoài niệm.', 1, 1),
(6, 'Sapa', '2023-03-15', 'Những buổi chợ phiên đem lại nhiều góc nhìn mới, đa dạng cho người dân miền xuôi khi ghé qua.', 1, 4),
(7, 'Nam Định', '2023-04-20', 'Quê hương của những người con xa xứ những năm tháng vào Nam mong một cuộc sống an yên.', 1, 1),
(8, 'Vũng Tàu', '2023-06-15', 'Đua xe ịn ịn trên cung đường trải dài dọc bờ biển dưới chân đèo mộc mạc, bình dị.', 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tour_diadiem`
--

CREATE TABLE `tour_diadiem` (
  `tour_MaTour` bigint(20) NOT NULL,
  `DiaDiem_MaDD` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `tour_diadiem`
--

INSERT INTO `tour_diadiem` (`tour_MaTour`, `DiaDiem_MaDD`) VALUES
(1, 1),
(2, 1),
(3, 3),
(4, 3),
(5, 2),
(6, 3),
(7, 1),
(8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tour_dichvu`
--

CREATE TABLE `tour_dichvu` (
  `tour_MaTour` bigint(20) NOT NULL,
  `dichvu_MaDV` bigint(20) NOT NULL,
  `TongTienDichVu` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `tour_dichvu`
--

INSERT INTO `tour_dichvu` (`tour_MaTour`, `dichvu_MaDV`, `TongTienDichVu`) VALUES
(1, 4, '700000.00'),
(2, 5, '900000.00'),
(3, 7, '700000.00'),
(4, 5, '900000.00'),
(5, 8, '900000.00'),
(6, 6, '700000.00'),
(7, 3, '700000.00'),
(8, 7, '700000.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `stripe_id` varchar(255) DEFAULT NULL,
  `pm_type` varchar(255) DEFAULT NULL,
  `pm_last_four` varchar(4) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `stripe_id`, `pm_type`, `pm_last_four`, `trial_ends_at`) VALUES
(2, 'Trần Minh', 'trannhatminh190102@gmail.com', NULL, '$2y$10$tYGdRHaonQwY8wmxyTwiKuNGC8q62Vxg30z3o/dLGda1vPU6cuvAW', NULL, '2023-03-16 02:30:22', '2023-03-18 23:17:33', 'cus_NYMHZJ544sM7JH', NULL, NULL, NULL),
(3, 'Minh Trần Nhật', '2051052081minh@ou.edu.vn', NULL, '$2y$10$UwUIWiIsBM5WY3Q6TPZRRuUDIDo47w2QOHWaZeLl0x0oTvJZezoAG', NULL, '2023-03-16 07:50:24', '2023-03-16 11:57:01', 'cus_NXQqvi3QfxoPox', NULL, NULL, NULL),
(4, 'Phạm Minh', 'nhutphamthi335@gmail.com', NULL, '$2y$10$4MlmK32kDPHrdU1idX17iOZU01wDz64dA.yAW2Y0IlTeDhQd6Y6FK', NULL, '2023-03-17 12:12:50', '2023-03-18 23:41:54', 'cus_NYMfjWaeWilbeH', NULL, NULL, NULL),
(5, 'Gia Hân', '52000752@student.tdtu.edu.vn', NULL, '$2y$10$ayxyLb8GM9XGw65qcd7h7etb8pjruxOgznr8ffG99BGkZNvMNfHii', NULL, '2023-03-19 00:01:41', '2023-03-19 00:03:14', 'cus_NYN0FGulIeCIpF', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chitietdattour`
--
ALTER TABLE `chitietdattour`
  ADD PRIMARY KEY (`khachhang_MaKH`,`tour_MaTour`),
  ADD KEY `fk_chitietdattour_tour` (`tour_MaTour`);

--
-- Indexes for table `diadiem`
--
ALTER TABLE `diadiem`
  ADD PRIMARY KEY (`MaDD`);

--
-- Indexes for table `dichvu`
--
ALTER TABLE `dichvu`
  ADD PRIMARY KEY (`MaDV`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `huongdanvien`
--
ALTER TABLE `huongdanvien`
  ADD PRIMARY KEY (`NhanVien_MaNV`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`MaKH`),
  ADD KEY `fk_khachhang_users` (`khachhang_users`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD PRIMARY KEY (`MaNV`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscriptions_stripe_id_unique` (`stripe_id`),
  ADD KEY `subscriptions_user_id_stripe_status_index` (`user_id`,`stripe_status`);

--
-- Indexes for table `subscription_items`
--
ALTER TABLE `subscription_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscription_items_subscription_id_stripe_price_unique` (`subscription_id`,`stripe_price`),
  ADD UNIQUE KEY `subscription_items_stripe_id_unique` (`stripe_id`);

--
-- Indexes for table `taikhoanadmin`
--
ALTER TABLE `taikhoanadmin`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_taikhoan_NhanVien1` (`NhanVien_MaNV`);

--
-- Indexes for table `tour`
--
ALTER TABLE `tour`
  ADD PRIMARY KEY (`MaTour`),
  ADD KEY `fk_tour_huongdanvien1` (`huongdanvien_NhanVien_MaNV`);

--
-- Indexes for table `tour_diadiem`
--
ALTER TABLE `tour_diadiem`
  ADD PRIMARY KEY (`tour_MaTour`,`DiaDiem_MaDD`),
  ADD KEY `fk_Tour_DiaDiem_DiaDiem1` (`DiaDiem_MaDD`);

--
-- Indexes for table `tour_dichvu`
--
ALTER TABLE `tour_dichvu`
  ADD PRIMARY KEY (`tour_MaTour`,`dichvu_MaDV`),
  ADD KEY `fk_tour_dichvu_dichvu1` (`dichvu_MaDV`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_stripe_id_index` (`stripe_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dichvu`
--
ALTER TABLE `dichvu`
  MODIFY `MaDV` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `nhanvien`
--
ALTER TABLE `nhanvien`
  MODIFY `MaNV` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_items`
--
ALTER TABLE `subscription_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tour`
--
ALTER TABLE `tour`
  MODIFY `MaTour` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chitietdattour`
--
ALTER TABLE `chitietdattour`
  ADD CONSTRAINT `fk_chitietdattour_khachhang1` FOREIGN KEY (`khachhang_MaKH`) REFERENCES `khachhang` (`MaKH`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_chitietdattour_tour` FOREIGN KEY (`tour_MaTour`) REFERENCES `tour` (`MaTour`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `huongdanvien`
--
ALTER TABLE `huongdanvien`
  ADD CONSTRAINT `fk_huongdanvien_NhanVien1` FOREIGN KEY (`NhanVien_MaNV`) REFERENCES `nhanvien` (`MaNV`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD CONSTRAINT `fk_khachhang_users` FOREIGN KEY (`khachhang_users`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `taikhoanadmin`
--
ALTER TABLE `taikhoanadmin`
  ADD CONSTRAINT `fk_taikhoan_NhanVien1` FOREIGN KEY (`NhanVien_MaNV`) REFERENCES `nhanvien` (`MaNV`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tour`
--
ALTER TABLE `tour`
  ADD CONSTRAINT `fk_tour_huongdanvien1` FOREIGN KEY (`huongdanvien_NhanVien_MaNV`) REFERENCES `huongdanvien` (`NhanVien_MaNV`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tour_diadiem`
--
ALTER TABLE `tour_diadiem`
  ADD CONSTRAINT `fk_Tour_DiaDiem_DiaDiem1` FOREIGN KEY (`DiaDiem_MaDD`) REFERENCES `diadiem` (`MaDD`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Tour_DiaDiem_tour1` FOREIGN KEY (`tour_MaTour`) REFERENCES `tour` (`MaTour`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tour_dichvu`
--
ALTER TABLE `tour_dichvu`
  ADD CONSTRAINT `fk_tour_dichvu_dichvu1` FOREIGN KEY (`dichvu_MaDV`) REFERENCES `dichvu` (`MaDV`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tour_dichvu_tour1` FOREIGN KEY (`tour_MaTour`) REFERENCES `tour` (`MaTour`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
